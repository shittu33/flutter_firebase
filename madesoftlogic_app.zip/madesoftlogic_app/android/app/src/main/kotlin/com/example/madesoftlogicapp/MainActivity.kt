package com.example.madesoftlogicapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
