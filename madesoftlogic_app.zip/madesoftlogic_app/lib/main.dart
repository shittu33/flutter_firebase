import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:madesoftlogicapp/Data.dart';
import 'package:madesoftlogicapp/customWidget/popUp.dart';

import 'addStaff.dart';
import 'customWidget/TabWidgets.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  static const homeRoute = '/';
  static const staffRoute = '/add staff';

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        homeRoute: (context) => MyHomePage(title: 'Home Page'),
        staffRoute: (context) => AddStaffScreen(),
      },
      title: 'Home',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ), initialRoute: homeRoute,
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title), actions: [
        TextPopUpMenuButton(
          iconColor: Colors.pink,
          onButtonTap: (choice) {},
          list: ["settings"],
        ),
        SizedBox(
          width: 20,
        )
      ]),
      body: NestedScrollView(
        headerSliverBuilder: (context, isScroll) {
          return <Widget>[
            TabWidget(
              tabsList: [
                new Tab(
                  child: Text(
                    "DashBoard",
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                ),
                new Tab(
                  child: Text(
                    "Activity",
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
              unselectedColor: Colors.grey,
              selectedColor: Colors.black,
            ),
          ];
        },
        body: MainContent(),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context,MyApp.staffRoute);
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class MainContent extends StatelessWidget {
  MainContent({
    Key key,
  }) : super(key: key);
  List<String> data = [
    "Sales Register",
    "Product/Service",
    "SMS",
    "Notifications",
    "Reports",
    "Sales",
    "Staffs",
    "Expenses",
    "Customers",
    "Offline Sales"
  ];

  @override
  Widget build(BuildContext context) {
    return Flex(direction: Axis.vertical, children: [
      TopCardWidget(),
      SizedBox(
        height: 2,
      ),
      Expanded(
        flex: 1,
        child: GridView.builder(
          itemCount: data.length,
          itemBuilder: (context, int position) {
//          var currentData = data[position];
            return CardItem(
              currentData: data[position],
            );
          },
          gridDelegate:
          SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        ),
      ),
    ]);
  }
}

class CardItem extends StatelessWidget {
  final String currentData;

  const CardItem({
    Key key,
    @required this.currentData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: Card(
        elevation: 2,
        child: GridTile(
          child: Container(
            constraints: BoxConstraints.expand(width: 100.0, height: 900.0),
            child: Center(
              child: Image.asset(
                "bell.png",
                width: 80,
                height: 80,
                fit: BoxFit.contain,
              ),
            ),
          ),
          footer: Center(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Text(currentData,
                    style: TextStyle(
                        fontSize: 23, fontWeight: FontWeight.bold)),
              )),
        ),
      ),
    );
  }
}

class TopCardWidget extends StatelessWidget {
  const TopCardWidget({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            Card(
              elevation: 5,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(18.0),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Today's Transaction",
                              style: TextStyle(fontSize: 20)),
                          SizedBox(
                            height: 8,
                          ),
                          Text(
                            "15 july 2020",
                            style: TextStyle(fontSize: 12, color: Colors.grey),
                          ),
                        ]),
                  ),
                  Container(
                    height: 1.5,
                    decoration: BoxDecoration(color: Colors.grey),
                  ),
//                  SizedBox(
//                    height: 20,
//                  ),
//                  SizedBox(width: 2),
                  Padding(
                    padding: const EdgeInsets.all(32.0),
                    child: Column(
                      children: [
                        PriceWidget(
                            bigSize: 40,
                            smallSize: 16,
                            priceTag: "Sales",
                            weigth: FontWeight.w600),
                        SizedBox(
                          height: 20,
                        ),
                        PriceBar(),
                        SizedBox(height: 20),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(0, 0, 108, 0),
                          child: PriceBar(),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
//            clipBehavior:,
            ),
          ],
        ),
      ),
    );
  }
}

class PriceBar extends StatelessWidget {
  const PriceBar({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.max,
      children: [
        Expanded(
          flex: 100,
          child: Container(
            height: 35,
            decoration: BoxDecoration(color: Colors.pink[100]),
            child: Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Expanded(
                  flex: 100,
                  child: Container(
                    decoration: BoxDecoration(color: Colors.pink),
                  ),
                ),
                Expanded(
                  flex: 35,
                  child: SizedBox(),
                )
              ],
            ),
          ),
        ),
        Expanded(
            flex: 30,
            child: PriceWidget(
                bigSize: 20,
                smallSize: 8,
                weigth: FontWeight.w600,
                priceTag: "Profit"))
      ],
    );
  }
}

class PriceWidget extends StatelessWidget {
  PriceWidget({
    Key key,
    this.bigSize,
    this.smallSize,
    @required this.weigth,
    @required this.priceTag,
  }) : super(key: key);
  final priceTag;

  final FontWeight weigth;
  double bigSize = 40;
  double smallSize = 16;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text("\u20A6 0.00",
            style: TextStyle(fontSize: bigSize, fontWeight: weigth)),
        Text(priceTag,
            style: TextStyle(fontSize: smallSize, fontWeight: weigth)),
      ],
    );
  }
}
